/*
 *   Author: Sean Mo    Date:05-01-2023
 *   Problem 4    Homework 11
 */

package h11;
import h11.GeometricObject;
public class Octagon extends GeometricObject implements Comparable<Octagon>, Cloneable {
    private double side;

    public Octagon() {
        this.side = 0;
    }

    public Octagon(double side) {
        this.side = side;
    }

    public double getSide() {
        return this.side;
    }

    public void setSide(double side) {
        this.side = side;
    }

    @Override
    public double getArea() {
        return 2 * (1 + Math.sqrt(2)) * Math.pow(this.side, 2);
    }

    @Override
    public double getPerimeter() {
        return 8 * this.side;
    }

    @Override
    public int compareTo(Octagon o) {
        if (this.side > o.getSide()) {
            return 1;
        } else if (this.side < o.getSide()) {
            return -1;
        } else {
            return 0;
        }
        
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
   
        public static void main(String[] args) 
        {
            Octagon octagon1 = new Octagon(5);
            System.out.println("The Area of the octagon is: " + octagon1.getArea());
            System.out.println("The perimeter of octagon is: " + octagon1.getPerimeter());

            try {
                Octagon octagon2 = (Octagon) octagon1.clone();
                int compare = octagon1.compareTo(octagon2);

                if (compare == 0) {
                    System.out.println("The two octaons have the same size.");
                } else if (compare == 1) {
                    System.out.println("octagon1 has a larger size than octagon2.");
                } else {
                    System.out.println("octagon1 has a smaller size than octagon2.");
                }
            } catch (CloneNotSupportedException e) {
                System.out.println("Clone not supported.");
            }
        }
    

}

