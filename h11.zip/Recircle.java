/*
 *   Author: Sean Mo    Date:05-01-2023
 *   Problem 3    Homework 11
 */

package h11;

public class Recircle extends GeometricObject implements Comparable<Recircle>
{

	private double radius;
	
	
	
	public Recircle() 
	{
		this.radius=0;
	}
	 
	public Recircle(double radius) 
	  {
		  this.radius = radius;
	  }
	
	 public Recircle(double radius, String color, boolean filled) 
	 {
		this.radius = radius;
	  	setColor(color);
	  	setFilled(filled);
     }
	 public double getRadius() 
	 {
		 return radius;
	 }
		 
	 /** Set a new radius */
	public void setRadius(double radius)
	{
	this.radius = radius;
	}
		
	/** Return area */
	public double getArea() {
	return radius * radius * Math.PI;
		  }
		 
	/** Return diameter */
	public double getDiameter() {
	return 2 * radius;
		 }
		 
	/** Return perimeter */
	public double getPerimeter() {
	return 2 * radius * Math.PI;
		}
		 
	/** Print the circle info */
	public void printCircle() {
	System.out.println("The circle is created " + getDateCreated() +
		 " and the radius is " + radius);
		  }
	
	@Override
	public int compareTo(Recircle o)
	{
		if (this.radius > o.getRadius())
			return 1;
		else if (this.radius < o.getRadius())
			return -1;
		else
			return 0;
	}
	 @Override
	 public boolean equals(Object o) {
	     if (o instanceof Recircle) {
	         Recircle c = (Recircle) o;
	         return this.compareTo(c) == 0;
	     }
	     return false;
	 }

	 
}

