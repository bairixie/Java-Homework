/*
 *   Author: Sean Mo    Date:05-01-2023
 *   Problem 2    Homework 11
 */
package h11;

import java.util.*;
import java.io.*;


public class Letter {
    public static void main(String[] args) 
   {
    	//Prompt the user to input the file name
        Scanner pd = new Scanner(System.in);
        System.out.print("Enter a file name: ");
       // read the file
        File file = new File (pd.nextLine());
        // exception if the file does not find
        try {
            Scanner rd = new Scanner(file);
            int[] count = new int[26];
            //read the file line by line
            while (rd.hasNextLine()) 
            {
                String line = rd.nextLine();
                for (int i = 0; i < line.length(); i++) 
                {
                    char ch = line.charAt(i);
                    //check if the character in the line is a letter
                    if (Character.isLetter(ch)) 
                    {
                        int id = Character.toLowerCase(ch) - 'a';
                        //count the letter 
                        count[id]++;
                    }
                }
            }
            //output of the letters and their occurrences
            for (int i = 0; i < 26; i++) 
            {
                System.out.println((char) (i + 'a') + ": " + count[i]);
            }
            rd.close();
            
            // Find the three most common letters
            int max1 = 0, max2 = 0, max3 = 0;
            char maxCh1 = ' ', maxCh2 = ' ', maxCh3 = ' ';
            for (int i = 0; i < 26; i++) 
            {
                if (count[i] > max1) {
                    max3 = max2;
                    maxCh3 = maxCh2;
                    max2 = max1;
                    maxCh2 = maxCh1;
                    max1 = count[i];
                    maxCh1 = (char) (i + 'a');
                } else if (count[i] > max2) {
                    max3 = max2;
                    maxCh3 = maxCh2;
                    max2 = count[i];
                    maxCh2 = (char) (i + 'a');
                } else if (count[i] > max3) {
                    max3 = count[i];
                    maxCh3 = (char) (i + 'a');
                }
            }
            System.out.println("Three most common letters are: " + maxCh1 + ", " + maxCh2 + ", " + maxCh3);

        } 
        catch (FileNotFoundException f) 
        {
            System.out.println("File not found ");
        }
    }
        
    
}


